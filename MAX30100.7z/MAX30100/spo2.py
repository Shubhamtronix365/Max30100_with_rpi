from max30100 import MAX30100
import time

mx30 = MAX30100()
mx30.enable_spo2()
mx30.set_led_current(50.0, 50.0)   # Increase LED current

while True:
    mx30.read_sensor()

    ir = mx30.ir
    red = mx30.red

    if ir < 1000:
        print("No finger detected")
    else:
        print("IR:", ir, "RED:", red)

    time.sleep(0.1)
