import time
import numpy as np
from max30100 import MAX30100
from scipy.signal import find_peaks
from RPLCD.i2c import CharLCD

# -------- LCD Setup --------
lcd = CharLCD('PCF8574', 0x27)
lcd.clear()

# -------- Sensor Setup --------
sensor = MAX30100()
sensor.enable_spo2()
sensor.set_led_current(50.0, 50.0)

BUFFER_SIZE = 200
ir_buffer = []
red_buffer = []

last_lcd_update = 0
bpm = 0
spo2 = 0

print("System Ready")
lcd.write_string("System Ready")
time.sleep(2)

lcd.clear()

while True:
    # -------- Continuous Sensor Reading --------
    sensor.read_sensor()
    ir = sensor.ir
    red = sensor.red

    if ir > 1000:   # Finger detected
        ir_buffer.append(ir)
        red_buffer.append(red)

        if len(ir_buffer) > BUFFER_SIZE:
            ir_buffer.pop(0)
            red_buffer.pop(0)

        if len(ir_buffer) == BUFFER_SIZE:
            ir_array = np.array(ir_buffer)
            red_array = np.array(red_buffer)

            ir_dc = np.mean(ir_array)
            red_dc = np.mean(red_array)

            ir_ac = ir_array - ir_dc
            red_ac = red_array - red_dc

            # ---- HEART RATE ----
            peaks, _ = find_peaks(ir_ac, distance=30)

            if len(peaks) > 1:
                peak_intervals = np.diff(peaks)
                avg_interval = np.mean(peak_intervals)
                bpm = int(60 * 100 / avg_interval)
            else:
                bpm = 0

            # ---- SPO2 ----
            ir_rms = np.sqrt(np.mean(ir_ac**2))
            red_rms = np.sqrt(np.mean(red_ac**2))

            if ir_dc != 0 and red_dc != 0:
                ratio = (red_rms / red_dc) / (ir_rms / ir_dc)
                spo2 = int(110 - 25 * ratio)
            else:
                spo2 = 0

            bpm = max(0, min(200, bpm))
            spo2 = max(0, min(100, spo2))

    else:
        bpm = 0
        spo2 = 0
        ir_buffer.clear()
        red_buffer.clear()

    # -------- Serial Output (continuous) --------
    print(f"HR: {bpm} BPM   SpO2: {spo2}%")

    # -------- LCD Update (ONLY every 1 second) --------
    if time.time() - last_lcd_update >= 1:

        lcd.cursor_pos = (0, 0)
        lcd.write_string("                ")
        lcd.cursor_pos = (0, 0)
        lcd.write_string(f"HR:{bpm} BPM")

        lcd.cursor_pos = (1, 0)
        lcd.write_string("                ")
        lcd.cursor_pos = (1, 0)
        lcd.write_string(f"SpO2:{spo2}%")

        last_lcd_update = time.time()

    time.sleep(0.01)
