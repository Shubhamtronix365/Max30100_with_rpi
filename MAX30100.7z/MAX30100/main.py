import time
import numpy as np
from max30100 import MAX30100
from scipy.signal import find_peaks

# Initialize sensor
sensor = MAX30100()
sensor.enable_spo2()
sensor.set_led_current(50.0, 50.0)

BUFFER_SIZE = 200
ir_buffer = []
red_buffer = []

print("Place finger on sensor...")

while True:
    sensor.read_sensor()
    
    ir = sensor.ir
    red = sensor.red

    # Finger detection threshold
    if ir < 1000:
        print("No finger detected")
        ir_buffer.clear()
        red_buffer.clear()
        time.sleep(0.1)
        continue

    ir_buffer.append(ir)
    red_buffer.append(red)

    if len(ir_buffer) > BUFFER_SIZE:
        ir_buffer.pop(0)
        red_buffer.pop(0)

    # Process when buffer full
    if len(ir_buffer) == BUFFER_SIZE:
        ir_array = np.array(ir_buffer)
        red_array = np.array(red_buffer)

        # Remove DC component
        ir_dc = np.mean(ir_array)
        red_dc = np.mean(red_array)

        ir_ac = ir_array - ir_dc
        red_ac = red_array - red_dc

        # -------- HEART RATE --------
        peaks, _ = find_peaks(ir_ac, distance=30)

        if len(peaks) > 1:
            peak_intervals = np.diff(peaks)
            avg_interval = np.mean(peak_intervals)

            # Sampling rate ≈ 100Hz
            bpm = 60 * 100 / avg_interval
        else:
            bpm = 0

        # -------- SPO2 --------
        ir_rms = np.sqrt(np.mean(ir_ac**2))
        red_rms = np.sqrt(np.mean(red_ac**2))

        if ir_dc != 0 and red_dc != 0:
            ratio = (red_rms / red_dc) / (ir_rms / ir_dc)
            spo2 = 110 - 25 * ratio
        else:
            spo2 = 0

        print(f"Heart Rate: {int(bpm)} BPM   SpO2: {int(spo2)} %")

    time.sleep(0.01)
